from sqlalchemy import create_engine # type: ignore
# from sqlalchemy.ext.declarative import declarative_base # type: ignore
from sqlalchemy.orm import sessionmaker, Session, declarative_base# type: ignore
from dotenv import load_dotenv  # type: ignore
import os

load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL")

# Fallback to AWS RDS if no environment variable is set
if not DATABASE_URL:
    DATABASE_URL = "postgresql+psycopg2://ghh:5XS9Nx6QWgxdlt2GZ8us@ai-food-app.cpyg4i0yu30w.ap-south-1.rds.amazonaws.com:5432/postgres"

# print(DATABASE_URL)

engine = create_engine(DATABASE_URL) # type: ignore
Sessionlocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()

def get_db():
    db = Sessionlocal()
    try:
        yield db
    finally:
        db.close()
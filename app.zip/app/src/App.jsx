import Login from './components/loginpage'

export default function App(){
    return <Login />
}


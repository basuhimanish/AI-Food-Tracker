from sqlalchemy.orm import Session  # type: ignore
from app.models import models
import requests # type: ignore
import cv2  # type: ignore
from pyzbar import pyzbar # type: ignore
from dotenv import load_dotenv
import os
from datetime import datetime, timedelta
import re
from sqlalchemy.orm import aliased
from sqlalchemy import and_, not_

load_dotenv()

OPENFOODFACTS_API = "https://world.openfoodfacts.org/api/v0/product"
SPOONACULAR_API = "https://api.spoonacular.com/recipes/findByIngredients"
SPOONACULAR_API_KEY = os.getenv("SPOONACULAR_API_KEY")
# ssh -p 443 -R0:localhost:8000 qr@a.pinggy.io

# Recipe Suggestion:
def get_recipes(ingredients):
    if not ingredients:
        return {"error": "No ingredients provided"}
    
    if not SPOONACULAR_API_KEY:
        return {"error": "Spoonacular API key not configured"}
    
    try:
        joined_ingredients = ",".join(ingredients)

        params = {
            "ingredients": joined_ingredients,
            "number": 10,  # Increased to 10 recipes
            "ranking": 1,
            "ignorePantry": True,
            "apikey": SPOONACULAR_API_KEY
        }
        
        url = f"{SPOONACULAR_API}?ingredients={joined_ingredients}&number={params.get('number')}&apiKey={SPOONACULAR_API_KEY}"
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            return {
                "success": True,
                "ingredients_used": ingredients,
                "recipes": data,
                "total_recipes": len(data) if isinstance(data, list) else 0
            }
        else:
            return {
                "error": f"API request failed with status {response.status_code}",
                "details": response.text
            }
            
    except requests.exceptions.RequestException as e:
        return {"error": f"Network error: {str(e)}"}
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}"}





# OPENFOODFACTS API
FOOD_CATEGORIES = [
    # Spreads & Condiments
    "jam", "jams", "jelly", "jellies", "chutney", "chutneys", "spread", "spreads",
    "peanut butter", "hazelnut spread", "nut butter", "mustard", "mustards",
    "ketchup", "mayonnaise", "mayo", "relish", "sauces", "sauce", "pesto",

    # Beverages
    "beverage", "beverages", "drink", "drinks", "juice", "juices", "soda", "sodas",
    "cola", "colas", "energy drink", "energy drinks", "sports drink", "sports drinks",
    "tea", "teas", "iced tea", "coffee", "coffees", "smoothie", "smoothies",
    "bottled water", "sparkling water", "flavored water", "water", "waters",

    # Snacks
    "chip", "chips", "crisps", "crisp", "snack", "snacks", "popcorn", "pretzel", "pretzels",
    "cracker", "crackers", "rice cake", "rice cakes", "trail mix", "energy bar", "protein bar",
    "bar", "bars", "granola", "granola bar", "nuts", "nut", "seeds", "seed",

    # Sweets & Confectionery
    "candy", "candies", "chocolate", "chocolates", "biscuit", "biscuits", "cookie", "cookies",
    "cake", "cakes", "pastry", "pastries", "donut", "donuts", "brownie", "brownies",
    "gum", "gums", "mint", "mints", "lollipop", "lollipops", "jellybean", "jellybeans",
    "marshmallow", "marshmallows", "toffee", "caramel", "pudding", "dessert", "desserts",

    # Dairy & Refrigerated
    "cheese", "cheeses", "butter", "butters", "yogurt", "yogurts", "milk", "milks", "ghee",
    "cream", "sour cream", "whipped cream", "dairy drink", "dairy dessert", "ice cream", "ice creams",

    # Breakfast Items
    "cereal", "cereals", "oatmeal", "muesli", "granola", "breakfast bar", "pancake", "waffle",

    # Bakery
    "bread", "breads", "bun", "buns", "bagel", "bagels", "muffin", "muffins", "croissant", "toast", "flour", "atta", "maida", "eggs", "egg"

    # Frozen Foods
    "frozen meal", "frozen meals", "frozen pizza", "frozen food", "frozen foods", "ice cream", "ice creams",

    # Ready-to-Eat / Instant
    "instant noodles", "ramen", "noodle soup", "cup soup", "ready meal", "ready meals", "canned soup", "microwave meal",

    # Baby & Kids
    "baby food", "baby foods", "infant formula", "kids snack", "kids juice",

    # Other
    "soup", "soups", "noodles", "pasta", "ravioli", "lasagna", "sushi", "salad", "salads"
]

def extract_quantity_from_text(text):
    if not text:
        return None

    # Units and patterns like 100g, 1kg, 250ml, 1.5l, 1 litre, etc.
    pattern = r'(\d+(?:[\.,]?\d+)?)(\s?)(g|gram|grams|kg|kilogram|kilograms|ml|l|litre|litres|oz|ounces)'
    match = re.search(pattern, text.lower())
    if match:
        return match.group(0).replace(",", ".")
    return None


def find_categories(keywords, categories, product_name_en):
    all_words = set()

    if keywords:
        all_words.update(k.lower() for k in keywords)
    if categories:
        all_words.update(c.strip().lower() for c in categories.split(","))
    if product_name_en:
        all_words.update(product_name_en.lower().split())

    for word in all_words:
        if word in FOOD_CATEGORIES:
            if(word == "atta"):
                word = "Wheat Flour"
            if(word == "maida"):
                word = "Refined Wheat Flour"
            return {"category": word, "categorystatus": True}

    return {"category": "", "categorystatus": False}


def filter_data(data):
    product = data.get("product", {})

    code = data.get("code")
    product_name_en = product.get("product_name_en")
    energy_kcal_100g = product.get("nutriments", {}).get("energy-kcal_100g")
    quantity = product.get("quantity")
    brands = product.get("brands")
    keywords = product.get("_keywords")
    categories = product.get("categories")
    imageurl = product.get("image_url")

    # Try extracting from quantity field first
    final_quantity = extract_quantity_from_text(quantity)

    # If not found, try from serving_size
    if not final_quantity:
        final_quantity = extract_quantity_from_text(product.get("serving_size"))

    # If still not found, try from product name
    if not final_quantity:
        final_quantity = extract_quantity_from_text(product_name_en)

    categorydata = find_categories(keywords, categories, product_name_en)

    data = {
        "code": code,
        "product_name_en": product_name_en,
        "energy_kcal_100g": energy_kcal_100g,
        "quantity": final_quantity,
        "brands": brands,
        "category": categorydata["category"],
        "categorystatus": categorydata["categorystatus"],
        "imageurl": imageurl
    }

    print(data)
    return data


def fetch_items_offAPI(barcode: str):
    url = f"{OPENFOODFACTS_API}/{barcode}.json"
    response = requests.get(url)
    data = response.json()

    if data.get("status") == 1:
        return filter_data(data)

    return {"Message": "failed: fetch_items_offAPI"}

# Barcode Scan

def scan_barcode_live():
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        barcodes = pyzbar.decode(frame)

        for barcode in barcodes:
            x, y, w, h = barcode.rect
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

            barcode_data = barcode.data.decode("utf-8")
            cap.release()
            cv2.destroyAllWindows()
            return barcode_data

        cv2.imshow('Barcode Scanner', frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    return None


def opencv_scan_barcode(image):
    frame = cv2.imread(f"./ai_food_tracker/app/images/{image}.jpg")

    barcodes = pyzbar.decode(frame)

    for barcode in barcodes:
        x, y, w, h = barcode.rect
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        barcode_data = barcode.data.decode("utf-8")

        print(barcode_data)


# Database Functions:

def add_to_database(db : Session, data, expirydate, user_id):

    try:
        f_id = int(data.get("code"))

        food_item = db.query(models.Food_Items).filter(models.Food_Items.f_id == f_id).first()

        if not food_item:
            food_item = models.Food_Items(
                f_id=f_id,
                f_name=data.get("product_name_en"),
                brands=data.get("brands"),
                quantity=data.get("quantity"),
                energy=data.get("energy_kcal_100g") or 0,
                category = data.get("category"),
                categorystatus = data.get("categorystatus"),
                imageurl = data.get("imageurl")
            )
            db.add(food_item)
            db.commit()
            db.refresh(food_item)

        inventory_item = models.Inventory(
            f_id=food_item.f_id,
            u_id=user_id,
            expiry_date=expirydate
        )
        db.add(inventory_item)
        db.commit()

        return {"message": "success"}

    except Exception as e:
        return {"message": "Failed to add item", "error": str(e)}

    
def add_user_to_database(db : Session, nm, mail, pwd):
    user = db.query(models.Users).filter(models.Users.email == mail).first()

    if user:
        return {"message" : "user already exists", "status" : False}


    user = models.Users(
        name = nm,
        email = mail,
        password = pwd
    )

    try:
        db.add(user)
        db.commit()
        db.refresh(user)

        return {"message" : "success", "status" : True}
        
    except Exception as e:
        return {"message" : e, "status" : False}



def verify_user_from_db(email, password, db):
    user = db.query(models.Users).filter(models.Users.email == email).first()

    if user and user.password == password:
        userid = str(user.id)
        username = user.name.capitalize()
        return {"userid" : userid,
                "username" : username,
                "status" : True}
    
    return {"userid" : "",
            "username" : "",
            "status" : False}

def user_inventory(userid: int, db, foodstatus, inventory):
    try:
        # First, check and move any expired items for this user
        expired_result = check_and_move_expired_items(db, userid)
        print(f"Expired items check: {expired_result}")
        
        # Subquery to get inventory IDs that are already logged in FoodStatusLog
        subquery = db.query(foodstatus.inventory_id).subquery()

        # Main query to fetch unlogged inventory items with food item details
        results = (
            db.query(inventory, models.Food_Items)
            .join(models.Food_Items, inventory.f_id == models.Food_Items.f_id)
            .filter(
                inventory.u_id == userid,
                ~inventory.id.in_(subquery)
            )
            .all()
        )

        inventory_data = []
        for inventory_item, food_item in results:
            inventory_data.append({
                "inventory_id": inventory_item.id,
                "expiry_date": inventory_item.expiry_date.strftime("%Y-%m-%d"),
                "f_id": inventory_item.f_id,
                "f_name": food_item.f_name,
                "brands": food_item.brands,
                "quantity": food_item.quantity,
                "energy": food_item.energy,
                "category": food_item.category,
                "categorystatus": food_item.categorystatus,
                "imageurl": food_item.imageurl,
            })

        return inventory_data

    except Exception as e:
        return {"message": "Failed to fetch inventory", "error": str(e)}


def get_expiring_items(db: Session, user_id: int, days: int = 3):
    
    try:
        today = datetime.now().date()  # Get today's date only
        upcoming = today + timedelta(days=days)

        expiring_items = db.query(models.Inventory).filter(
            models.Inventory.u_id == user_id,
            models.Inventory.expiry_date >= datetime.combine(today, datetime.min.time()),
            models.Inventory.expiry_date <= datetime.combine(upcoming, datetime.max.time())
        ).all()

        return expiring_items
    
    except Exception as e:
        return {"message":e}

def update_food_status(db:Session,foodstatus):
    try:
        food_status_log = models.FoodStatusLog(
            inventory_id=foodstatus.inventory_id,
            status=foodstatus.status,
            notes=foodstatus.notes,
            timestamp=datetime.now()
        )
        db.add(food_status_log)
        db.commit()
        db.refresh(food_status_log)
        return {"message": "success"}
    except Exception as e:
        return {"message": "Failed to update food status", "error": str(e)}


def delete_inventory_item(db: Session, inventory_id: int, user_id: int):
    try:
        # First check if the item belongs to the user
        inventory_item = db.query(models.Inventory).filter(
            models.Inventory.id == inventory_id,
            models.Inventory.u_id == user_id
        ).first()
        
        if not inventory_item:
            return {"message": "Item not found or not authorized", "status": False}
        
        # Delete the inventory item
        db.delete(inventory_item)
        db.commit()
        
        return {"message": "Item deleted successfully", "status": True}
        
    except Exception as e:
        return {"message": "Failed to delete item", "error": str(e), "status": False}


def check_and_move_expired_items(db: Session, user_id: int = None):
    """
    Check for expired items and automatically move them to FoodStatusLog with 'expired' status.
    Items are considered expired when the current date is greater than the expiry date.
    If user_id is provided, only check that user's items. Otherwise, check all users.
    """
    try:
        today = datetime.now().date()  # Get today's date only (without time)
        
        # Query for expired items - compare dates only
        query = db.query(models.Inventory).filter(
            models.Inventory.expiry_date < datetime.combine(today, datetime.min.time())
        )
        
        if user_id is not None:
            query = query.filter(models.Inventory.u_id == user_id)
        
        expired_items = query.all()
        
        moved_count = 0
        for item in expired_items:
            # Check if this item is already in FoodStatusLog
            existing_log = db.query(models.FoodStatusLog).filter(
                models.FoodStatusLog.inventory_id == item.id
            ).first()
            
            if not existing_log:
                # Move to FoodStatusLog with 'expired' status
                food_status_log = models.FoodStatusLog(
                    inventory_id=item.id,
                    status="expired",
                    notes="Automatically moved due to expiration",
                    timestamp=datetime.now()
                )
                db.add(food_status_log)
                moved_count += 1
        
        if moved_count > 0:
            db.commit()
            return {"message": f"Moved {moved_count} expired items to FoodStatusLog", "moved_count": moved_count}
        else:
            return {"message": "No expired items found", "moved_count": 0}
            
    except Exception as e:
        return {"message": "Failed to check expired items", "error": str(e)}


